package org.example.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "Publisher")
@Data
public class Publisher {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "publisher_id")
    private int publisherId;

    @Column(name = "name")
    private String name;
}
