package org.example.Controller;

import org.example.dto.BookDTO;
import org.example.model.Author;
import org.example.model.Book;
import org.example.model.Publisher;
import org.example.Service.AuthorService;
import org.example.Service.BookService;
import org.example.Service.PublisherService;
import org.example.util.JDBCUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@RestController
public class BookController {

    @Autowired
    private BookService bookService;
    @Autowired
    private AuthorService authorService;
    @Autowired
    private PublisherService publisherService;

    @GetMapping("/books")
    public List<Book> getAllBooks() {
        System.out.println(bookService.getAllBooks());
        return new ArrayList<>();
    }

    @PostMapping("/books")
    public String addBook(@RequestBody BookDTO bookDTO) {
        try (Connection connection = JDBCUtil.getConnection()) {
//            Author author = authorService.getAuthorById(bookDTO.getAuthorId());
//            if (author == null) {
//                author = new Author();
//                author.setName(book.getAuthor().getName());
//                authorService.saveAuthor(author);
//            }
//            book.setAuthor(author);
//
//            Publisher publisher = publisherService.getPublisherByName(book.getPublisher().getName());
//            if (publisher == null) {
//                publisher = new Publisher();
//                publisher.setName(book.getPublisher().getName());
//                publisherService.savePublisher(publisher);
//            }
//            book.setPublisher(publisher);

            Book book = new Book();
            Author author = new Author();// get author by ID from DB
            author.setId(bookDTO.getAuthorId());
            Publisher publisher = new Publisher();// get publisher by ID from DB
            publisher.setPublisherId(bookDTO.getPublisherId());
            book.setAuthor(author);
            book.setPublisher(publisher);
            book.setTitle(bookDTO.getTitle());

            bookService.saveBook(book);

            return "Book Added Successfully";
        } catch (SQLException e) {
            return ("Error" + e.getMessage());
        }
    }
}
