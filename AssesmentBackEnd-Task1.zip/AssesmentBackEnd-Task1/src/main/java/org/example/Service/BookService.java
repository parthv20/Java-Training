package org.example.Service;

import org.example.Repositry.BookRepo;
import org.example.model.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class BookService {

    @Autowired
    private BookRepo bookRepo;

    public List<Book> getAllBooks(){
        return bookRepo.getAllBooks();
    }

    public void saveBook(Book book){
        bookRepo.saveBook(book);
    }
}
