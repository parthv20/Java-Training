package org.example.Service;

import org.example.Repositry.PublisherRepo;
import org.example.model.Publisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class PublisherService {

    @Autowired
    private PublisherRepo publisherRepo;

    public Publisher getPublisherByName(String name){
        return publisherRepo.getPublisherByName(name);
    }

    public void savePublisher(Publisher publisher){
        publisherRepo.savePublisher(publisher);
    }
}
