package org.example.Repositry;




import org.example.model.Book;
import jakarta.transaction.Transactional;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class BookRepo {

    @Autowired
    private SessionFactory sessionFactory;

    @Transactional
    public List<Book> getAllBooks() {
        Session session = sessionFactory.getCurrentSession();
        return session.createQuery("FROM Book", Book.class).getResultList();
    }

    @Transactional
    public void saveBook(Book book) {
        sessionFactory.getCurrentSession().saveOrUpdate(book);
    }
}