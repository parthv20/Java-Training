package org.example.Repositry;

import org.example.model.Author;
import jakarta.transaction.Transactional;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class AuthorRepo {

    @Autowired
    private SessionFactory sessionFactory;

    @Transactional
    public Author getAuthorByName(String name) {
        Session session = sessionFactory.getCurrentSession();

        List<Author> authors = session
                .createQuery("FROM Author WHERE name = :name", Author.class)
                .setParameter("name", name)
                .getResultList();

        return authors.isEmpty() ? null : authors.get(0);
    }

    @Transactional
    public void saveAuthor(Author author) {
        sessionFactory.getCurrentSession().saveOrUpdate(author);
    }
}
