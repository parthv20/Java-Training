package org.example.Repositry;


import jakarta.transaction.Transactional;
import org.example.model.Publisher;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class PublisherRepo {

    @Autowired
    private SessionFactory sessionFactory;

    @Transactional
    public Publisher getPublisherByName(String name) {
        Session session = sessionFactory.getCurrentSession();
        List<Publisher> publishers = session.createQuery("FROM Publisher WHERE name = :name", Publisher.class)
                .setParameter("name", name)
                .getResultList();
        return publishers.isEmpty() ? null : publishers.get(0);
    }

    @Transactional
    public void savePublisher(Publisher publisher) {
        sessionFactory.getCurrentSession().saveOrUpdate(publisher);
    }
}