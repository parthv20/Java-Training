package org.example.dto;

import org.example.model.Author;
import org.example.model.Publisher;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookDTO {
    @JsonProperty("id")
    private int id;
    @JsonProperty("title")
    private String title;
    @JsonProperty("publication_year")
    private int publicationYear;
    @JsonProperty("author_id")
    private int authorId;
    @JsonProperty("publisher_id")
    private int publisherId;
}
